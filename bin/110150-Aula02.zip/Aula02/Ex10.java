package Aula02;

import java.util.Scanner;

public class Ex10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("introduza um numero: ");
        double n = sc.nextDouble();
        double maxvalue = n;
        double minvalue = n;
        int numval = 0;
        double total = 0;
        while(true){
            // System.out.print("digite entre ()");
            double nextnumber = sc.nextDouble();
            if(nextnumber == 0) break;
            if(nextnumber > maxvalue) maxvalue = nextnumber;
            if(nextnumber < minvalue) minvalue = nextnumber;
            numval ++;
            total += n;

        }
        double a = total/numval;
        System.out.println("Maxnum value: " + maxvalue);
        System.out.println("Minnum value: " + minvalue);
        System.out.println("a value: " + a);
        System.out.println("Todas de numeros: " + numval);
        
        sc.close();


        
    }
    
}
