// package Treino;

// import java.util.Scanner;

// public class Ex02 {
//     public static void main(String[] args) {
//         double km, miles;
//         Scanner sc = new Scanner(System.in){
//             System.out.println("Distancia em km: ");
//             km = sc.nextDouble();
//         }
//         miles = km/1.609;
//         System.out.println("Distancia miles: " + miles);
//         sc.close();
//     }
    
// }
