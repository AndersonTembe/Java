package Treino;

import java.util.Scanner;

public class Treino05 {
    public static void main(String[] args) {
        double v1,d1,v2,d2;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduza a v1: ");
        v1 = sc.nextDouble();
        System.out.println("introduza a d1: ");
        d1 = sc.nextDouble();
        System.out.println("Introduza a v2: ");
        v2 = sc.nextDouble();
        System.out.println("Introduza a d2: ");
        d2 = sc.nextDouble();
        // double vf = (v1*v2(d1+d2))/(d1*v2+d2*v1);
        double v = (v1*v2*d1+d2)/(d1*v2+d2*v1);
        System.out.println("valocidade media final: "+v+ "km");

        sc.close();

        
    }
    
}
