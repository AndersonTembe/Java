package Treino;

import java.util.Scanner;

public class Ex04 {
    public static void main(String[] args) {
        double m,ti,tf,q;
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Water: ");
            m =sc.nextDouble();
            System.out.println("Temperatura inicial: ");
            ti = sc.nextDouble();
            System.out.println("temperatura Final: ");
            tf = sc.nextDouble();
        }
        q =m*(tf-ti)*4184;
        System.out.println("q = " +q+ "j");
        
        
    }
    
}
