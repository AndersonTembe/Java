package Treino;

import java.util.Scanner;

public class Ex05 {
    public static void main(String[] args) {
        double notaP, notaT, notaF;
        try (Scanner sc = new Scanner(System.in)) {
            try {
                System.out.println("introduza a nota P: ");
                notaP  = sc.nextDouble();
                System.out.println("introduza a nota T: ");
                notaT = sc.nextDouble();

                if (notaP < 7.0 || notaT < 7.0){
                    System.out.println("REP");
                }else{
                    notaF = ((0.4*notaT)) + (0.6*notaP);
                    System.out.println("Nota Final: " + notaF);

                }

                
            } catch (Exception e) {
                System.out.println("os valores estao incorretos");
            }
        }
}

}