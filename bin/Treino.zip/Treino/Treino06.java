package Treino;

import java.util.Scanner;

public class Treino06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        


        sc.close();
        
    }
    
}
