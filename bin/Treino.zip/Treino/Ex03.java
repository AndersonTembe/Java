package Treino;

import java.util.Scanner;

public class Ex03 {
    public static void main(String[] args) {
        double c,f;
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Celsius: ");
            c = sc.nextDouble();
            f = 1.8 * c + 32;
            System.out.println("F" + f);
            f = sc.nextDouble();
        }
        
    }
    
}
