package Treino;
import java.util.Date;

public class Ex01 {
    public static void main(String[] args) {
        Date data = new Date();
        System.out.println("A hora do sistema e ");
        System.out.println(data.toString());





     

        
    }
    
}
