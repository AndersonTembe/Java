package Treino;

import java.util.Scanner;

public class Treino04 {
    public static void main(String[] args) {
        double ti,tf,m,q;
        Scanner sc = new Scanner(System.in);
        System.out.println("Water : ");
        m = sc.nextDouble();
        System.out.println("Temperatura Inicial: ");
        ti = sc.nextDouble();
        System.out.println("Temperatura Final: ");
        tf = sc.nextDouble();
        sc.close();
        {
            q = m*(tf-ti)*4184;
            System.out.println("q= "+q+ "j");
        }

         


    }
    
}
