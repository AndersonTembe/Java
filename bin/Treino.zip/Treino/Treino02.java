package Treino;

import java.util.Scanner;

public class Treino02 {
    public static void main(String[] args) {
        double km, m;
        Scanner sc = new Scanner(System.in);
        System.out.println("Distancia: ");
        km = sc.nextDouble();
        m = km/1.609;
        System.out.println("A con versao e de: "+ m);


        sc.close();
    }
    
}
